/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rendi.program;


import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 *
 * @author Rebasya
 */
public class Konfig {
private static Connection MySQLConfig;
    public static Connection KonfigDB() throws SQLException {
        try {
            String url ="jdbc:mysql://localhost/tugasbesaralgo";
            String user="root";
            String pass="";
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            MySQLConfig = (Connection) DriverManager.getConnection(url, user, pass);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Koneksi ke DataBase Gagal","Error",
            JOptionPane.INFORMATION_MESSAGE);
            System.err.println(e.getMessage());
            System.exit(0);
        }
         return MySQLConfig;
    }
    

}